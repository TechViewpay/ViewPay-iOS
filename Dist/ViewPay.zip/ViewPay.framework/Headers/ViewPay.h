//
//  ViewPay.h
//  ViewPay
//
//  Created by Thibaut LE LEVIER on 29/11/2017.
//  Copyright © 2017 ViewPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for ViewPay.
FOUNDATION_EXPORT double ViewPayVersionNumber;

//! Project version string for ViewPay.
FOUNDATION_EXPORT const unsigned char ViewPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ViewPay/PublicHeader.h>

@interface ViewPay : NSObject

+ (void)sayHello;

@end
